"""
Pure payload-shaping functions for the five real outbound Everyticket
webhook events (2026-09 follow-up 3 - Vishal's own numbered list:
"Add one more webhook for renew"; trimmed every payload down to exactly
the fields he listed, and simplified the wire envelope to just
event_type + payload):

  1. onboarding_payload  - subscription.activated, first-time signup.
     Payload: subscription_id, email, phone_number, plan_code, plan_name,
     price, is_trial, expires_at, plus every registration-form answer
     merged in FLAT at the top level (2026-09-11 follow-up: "Keep the
     key for email and phone number as below shown in JSON... Pass
     payload like this flat structure including registration form
     data.." - registration_data used to be nested under its own key;
     it is now spread directly alongside the other fields instead, and
     the phone number's wire key changed from "mobile" to
     "phone_number" - the Customer model's own column is still called
     mobile, only the outbound JSON key name changed).
  2. renewed_payload  - subscription.renewed, an existing subscription
     is renewed on its current plan. Payload: subscription_id only.
  3. expiry_payload   - subscription.expired, plan expires unrenewed.
     Payload: subscription_id only.
  4. cancelled_payload - subscription.cancelled, a customer cancels.
     Payload: subscription_id only.
  5. archive_payload  - subscription.archived, still unrenewed after the
     admin-configured archive_after_days window. Payload: subscription_id
     only.

Deliberately built from primitives, not ORM objects, so the exact same
function that shapes a REAL delivery's payload (app.payments.service /
app.subscriptions.service) also shapes the admin Configuration screen's
read-only "sample JSON" preview (app.api.v1.admin_config) - one source
of truth, so the documentation can never quietly drift from what's
actually sent over the wire. The wire envelope itself (event_type +
payload) is built by app.webhooks.service.build_wire_body().

build_webhook_samples() below (2026-09-13 follow-up: moved here, out of
admin_config.py, so the admin Testing page's new "Test Everyticket
webhook" event dropdown - app.api.v1.admin_testing.get_webhook_samples -
can reuse the EXACT same five sample bodies the Configuration screen's
preview shows, rather than a second, easily-drifting copy) builds the
full list of {event, trigger, payload} samples for all five real event
types, application-aware (reflects this application's actual
registration-form fields and an active plan when one exists).
"""
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session


def onboarding_payload(
    *,
    subscription_id: str,
    email: str | None,
    mobile: str | None,
    plan_code: str,
    plan_name: str,
    price: float,
    is_trial: bool,
    expires_at: str | None,
    registration_data: dict,
) -> dict:
    """subscription.activated - fires exactly once, the moment a NEW
    subscription's payment succeeds (never on renew/upgrade/downgrade -
    see app.payments.service.process_gateway_result's payment_type
    branch, which routes those to their own event_type instead).
    Carries every registration-form answer the customer submitted at
    signup (registration_data - see app.customers.models.
    CustomerRegistrationData) so Everyticket can provision the account
    without a second round-trip to ask for the same details.

    email/mobile were re-added in an earlier follow-up ("in activated
    json, customer data also need to be there.. email and mobile as
    part of payload or registration data") - kept as their own
    top-level fields rather than folded into registration_data, since
    they're account-level identity, not a form answer, and every
    subscribe flow has them regardless of what the registration form
    asks.

    2026-09-11 follow-up ("Keep the key for email and phone number as
    below shown in JSON: {email, phone_number}... Pass payload like
    this flat structure including registration form data.."): the wire
    key for the customer's mobile number is now "phone_number" (this
    function's own `mobile` parameter name is unchanged - it still maps
    onto the Customer model's own `mobile` column, only the JSON key
    sent over the wire changed), and registration_data's fields are now
    spread directly at the top level of the payload instead of nested
    under a "registration_data" key - the fixed fields below always
    win if a registration form's field_key happens to collide with one
    of them, so a customer-editable form answer can never silently
    overwrite subscription_id/email/phone_number/plan/price/trial/expiry.

    Still no customer_id or external identity here - trimmed to exactly
    the fields Vishal asked to keep. Everyticket's own response to THIS
    delivery is what assigns the external identity (spec section 32) -
    see app.webhooks.service._handle_activation_outcome, which upserts
    CustomerApplicationMapping from that response."""
    return {
        **registration_data,
        "subscription_id": subscription_id,
        "email": email,
        "phone_number": mobile,
        "plan_code": plan_code,
        "plan_name": plan_name,
        "price": price,
        "is_trial": is_trial,
        "expires_at": expires_at,
    }


def _subscription_id_only_payload(subscription_id: str) -> dict:
    """Shared shape for every lifecycle event Vishal asked to trim down
    to just the subscription identifier - renew, expire, cancel, archive
    all resolve everything else about the subscription by looking it up
    with this ID, rather than carrying a snapshot of fields that can go
    stale between when the event is queued and when Everyticket reads
    it."""
    return {"subscription_id": subscription_id}


def renewed_payload(*, subscription_id: str) -> dict:
    """subscription.renewed - fires once an existing subscription's
    RENEWAL payment succeeds (app.payments.service.process_gateway_result),
    extending expires_at on the same plan."""
    return _subscription_id_only_payload(subscription_id)


def expiry_payload(*, subscription_id: str) -> dict:
    """subscription.expired - fires once when an ACTIVE subscription's
    expires_at passes without a renewal (app.subscriptions.service.
    expire_due_subscriptions, a Celery beat sweep - see celery_app.py's
    beat_schedule)."""
    return _subscription_id_only_payload(subscription_id)


def cancelled_payload(*, subscription_id: str) -> dict:
    """subscription.cancelled - fires once a customer (or an admin, via
    the Testing module) cancels a subscription immediately (spec section
    43: no refund, no future renewal) - see
    app.subscriptions.service.cancel_subscription."""
    return _subscription_id_only_payload(subscription_id)


def archive_payload(*, subscription_id: str) -> dict:
    """subscription.archived - fires once an EXPIRED subscription has
    stayed unrenewed for at least the application's admin-configured
    archive_after_days (app.subscriptions.service.archive_stale_subscriptions,
    also a Celery beat sweep)."""
    return _subscription_id_only_payload(subscription_id)


def _sample_value_for_field(field) -> object:
    """Illustrative, obviously-fake example value for one registration
    field, type-appropriate so the onboarding sample below reads as real
    data rather than a wall of "string" placeholders."""
    if field.options:
        first = field.options[0]
        return first.get("value", first) if isinstance(first, dict) else first
    if field.field_type in ("number", "integer"):
        return 42
    if field.field_type in ("checkbox", "boolean"):
        return True
    if field.field_type == "email":
        return "sample@example.com"
    if field.placeholder:
        return field.placeholder
    return f"Sample {field.label}"


def build_webhook_samples(db: Session, application) -> list:
    """Read-only preview of the exact JSON each of the five real
    outbound webhook events sends (2026-09 follow-up: "Webhook for
    everyticket app are as below: 1) onboarding... 2) status inactive
    when plan expires... 3) delete/archive when user do not renew for x
    days"; follow-up 3: "Add one more webhook for renew"). Registration-
    field keys are pulled from this application's real, currently-
    configured form (falling back to two generic example fields if none
    are configured yet), and plan_code/name/price come from a real active
    plan when one exists, so the onboarding sample reflects this
    application's actual setup rather than being entirely made up. The
    other four events are trimmed to just subscription_id (2026-09
    follow-up 3), so there is nothing application-specific left to
    reflect for them.

    Used by BOTH the admin Configuration screen's read-only preview
    (app.api.v1.admin_config) and the admin Testing page's "Test
    Everyticket webhook" event dropdown (app.api.v1.admin_testing) - one
    shared function so the two can never quietly drift apart. Local
    imports avoid a circular import (app.applications.config_schemas and
    app.forms.models/app.plans.models don't need to know about this
    module; only this function needs them)."""
    from app.applications.config_schemas import EveryticketWebhookSampleOut
    from app.forms.models import RegistrationFormField
    from app.plans.models import Plan
    from app.webhooks.service import build_wire_body

    now = datetime.now(timezone.utc)
    fields = (
        db.query(RegistrationFormField)
        .filter(RegistrationFormField.application_id == application.id, RegistrationFormField.active.is_(True))
        .order_by(RegistrationFormField.display_order)
        .all()
    )
    registration_data = (
        {f.field_key: _sample_value_for_field(f) for f in fields}
        if fields
        else {"organization_name": "Sample Museum", "contact_person": "Jane Doe"}
    )

    plan = (
        db.query(Plan)
        .filter(Plan.application_id == application.id, Plan.active.is_(True), Plan.is_trial.is_(False))
        .order_by(Plan.price)
        .first()
    )
    plan_code = plan.plan_code if plan else "PRO"
    plan_name = plan.name if plan else "Pro Plan"
    price = float(plan.price) if plan else 999.0

    sample_subscription_id = "SUB-000123"

    onboarding = onboarding_payload(
        subscription_id=sample_subscription_id,
        email="customer@example.com",
        mobile="9999999999",
        plan_code=plan_code,
        plan_name=plan_name,
        price=price,
        is_trial=False,
        expires_at=(now + timedelta(days=30)).isoformat(),
        registration_data=registration_data,
    )
    renewed = renewed_payload(subscription_id=sample_subscription_id)
    expired = expiry_payload(subscription_id=sample_subscription_id)
    cancelled = cancelled_payload(subscription_id=sample_subscription_id)
    archived = archive_payload(subscription_id=sample_subscription_id)

    # Wrapped via the SAME build_wire_body() a real delivery uses (see
    # app.webhooks.service._attempt_one) - just {event_type, payload}, so
    # the preview below is the literal JSON body Everyticket's endpoint
    # would receive, not just the inner event data.
    events = [
        ("subscription.activated", onboarding, "Onboarding: fires once, the first time a new customer's payment succeeds."),
        ("subscription.renewed", renewed, "Renew: fires once an existing subscription's renewal payment succeeds."),
        ("subscription.expired", expired, "Status inactive: fires once when an active subscription's plan expires unrenewed."),
        ("subscription.cancelled", cancelled, "Cancel: fires once a customer cancels their subscription immediately."),
        (
            "subscription.archived",
            archived,
            "Delete/archive: fires once an expired subscription has stayed unrenewed past the Archive after "
            "threshold below (disabled until that field is set).",
        ),
    ]
    return [
        EveryticketWebhookSampleOut(
            event=event_type,
            trigger=trigger,
            payload=build_wire_body(event_type=event_type, payload=event_payload),
        )
        for event_type, event_payload, trigger in events
    ]
